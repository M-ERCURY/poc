Mercury forwards all traffic on a system
```bash
# start the client
sudo ./mercury start

# stop the client
./mercury stop